﻿namespace DataBase.Tp_5.Models
{
    public class DbContext<T>
    {
    }
}