﻿select *from Location
insert into Location (Place,Detail)values('noida','this is nice place')
select *from customer
insert into Customer values('Shubham','Shubham@gmial.com',2),
('Anoop','anoop@gmial.com',1),
('Alok','alok@gmial.com',3),
('Himanshu','himanshu@gmial.com',2)
select *from Location
select *from customer
select *from Location